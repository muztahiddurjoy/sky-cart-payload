# This repo has moved!

This repo has been merged into the [Payload Examples Directory](https://github.com/payloadcms/payload/tree/main/examples). Please refer to the [Custom Server Example](https://github.com/payloadcms/payload/tree/main/examples/custom-server) for all the latest updates.
